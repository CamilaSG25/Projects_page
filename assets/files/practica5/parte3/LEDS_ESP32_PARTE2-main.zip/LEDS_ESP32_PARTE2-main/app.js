// ===============================
// BACKEND IP (TU FLASK)
// ===============================
//PARA MI RED DE MI CELULAR 
//const BACK = "https://172.20.10.5:5000";
// RED DE MI CASA PARA LA PARTE 2
//const BACK = "https://192.168.0.101:5000";

//PARA LA PARTE 3
const BACK = "https://leds-esp32-back-render.onrender.com";

// ===============================
// ELEMENTOS
// ===============================
const colorPicker = document.getElementById("colorPicker");
const btnPick = document.getElementById("btnPick");
const hexText = document.getElementById("hexText");

const dots = document.getElementById("dots");
const barDots = document.getElementById("barDots");

const btnSend = document.getElementById("btnSend");
const btnOff  = document.getElementById("btnOff");
const lastUpdate = document.getElementById("lastUpdate");

const MAX = 8;

// ===============================
// ESTADO TEMPORAL (NO SE ENVÍA HASTA PRESIONAR)
// ===============================
let draftCount = 3;
let draftColor = "#7682CF";
let dirty = false;

// ===============================
// CREAR DOTS
// ===============================
function makeDots(container, max){
  container.innerHTML = "";
  for(let i=1;i<=max;i++){
    const d = document.createElement("div");
    d.className = "dot";
    d.title = i;

    d.addEventListener("click", () => {
      draftCount = i;
      dirty = true;
      render();
    });

    container.appendChild(d);
  }
}

// ===============================
// RENDER VISUAL
// ===============================
function render(){
  // texto + el propio input muestra el color
  hexText.textContent = draftColor.toUpperCase();
  colorPicker.value = draftColor;

  // dots izquierda: ahora sí se pintan del color
  [...dots.children].forEach((d, idx) => {
    const on = idx < draftCount;
    d.style.background = on ? draftColor : "rgba(255,255,255,.35)";
  });

  // barra derecha: preview de cómo se verá en ESP32
  [...barDots.children].forEach((d, idx) => {
    d.style.background = (idx < draftCount) ? draftColor : "rgba(255,255,255,.28)";
  });
}

// ===============================
// ENVIAR ESTADO AL BACK
// ===============================
async function sendState(){
  const payload = {
    color: draftColor.toUpperCase(),
    count: draftCount
  };

  await fetch(`${BACK}/api/set`, {
    method:"POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify(payload)
  });
}

// ===============================
// LEER ESTADO DEL BACK
// ===============================
async function pullState(){
  const r = await fetch(`${BACK}/api/state`);
  const s = await r.json();

  if(dirty) return; // si el usuario está editando, no sobrescribir

  draftColor = s.color;
  draftCount = s.count;

  if(lastUpdate){
    lastUpdate.textContent = "Última actualización: " + (s.updated || "");
  }

  render();
}

// ===============================
// EVENTOS
// ===============================

colorPicker.addEventListener("input", () => {
  draftColor = colorPicker.value;
  dirty = true;
  render();
});

btnSend.addEventListener("click", async () => {
  await sendState();
  dirty = false;
});

btnOff.addEventListener("click", async () => {
  draftCount = 0;
  dirty = true;   // estás editando
  render();
  await sendState();
  dirty = false;  // ya sincronizado
});

// ===============================
// INIT
// ===============================
makeDots(dots, MAX);
makeDots(barDots, MAX);
render();
pullState();
setInterval(pullState, 2000);