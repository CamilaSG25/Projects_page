const colorPicker = document.getElementById("colorPicker");
const btnPick = document.getElementById("btnPick");
const swatch = document.getElementById("swatch");
const hexText = document.getElementById("hexText");

const dots = document.getElementById("dots");
const barDots = document.getElementById("barDots");

const btnSend = document.getElementById("btnSend");
const btnOff  = document.getElementById("btnOff");
const lastUpdate = document.getElementById("lastUpdate");

const MAX = 8; // puntos en la UI

// ====== ESTADO LOCAL (draft) ======
let draftCount = 3;
let draftColor = "#7682CF";

// Si dirty=true significa: "tengo cambios locales NO enviados"
let dirty = false;

function makeDots(container, max){
  container.innerHTML = "";
  for(let i=1;i<=max;i++){
    const d = document.createElement("div");
    d.className = "dot";
    d.title = i;

    d.addEventListener("click", () => {
      draftCount = i;
      dirty = true;      // <- NO permitir que el server lo sobrescriba
      render();
    });

    container.appendChild(d);
  }
}

function render(){
  hexText.textContent = draftColor.toUpperCase();
  swatch.style.background = draftColor;

  [...dots.children].forEach((d, idx) => {
    d.classList.toggle("on", idx < draftCount);
  });

  [...barDots.children].forEach((d, idx) => {
    d.style.background = (idx < draftCount) ? draftColor : "rgba(255,255,255,.28)";
  });
}

async function sendState(){
  const payload = {
    color: draftColor.toUpperCase(),
    count: draftCount
  };

  const r = await fetch("/api/set", {
    method:"POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify(payload)
  });

  if(!r.ok){
    console.error("Error enviando /api/set:", await r.text());
  }
}

async function pullState(){
  const r = await fetch("/api/state");
  const s = await r.json();

  // Siempre actualizamos el texto de última actualización
  lastUpdate.textContent = s.updated ? `Última actualización: ${s.updated}` : "";

  // Si hay cambios locales sin enviar, NO sobrescribimos la UI
  if (dirty) return;

  // Si no hay cambios locales, sincroniza UI con servidor
  draftColor = (s.color || "#7682CF").toUpperCase();
  draftCount = Number(s.count ?? 0);

  // mantener el input alineado
  colorPicker.value = draftColor;
  render();
}

/* ========= EVENTOS ========= */

// Abrir el selector con el botón
btnPick.addEventListener("click", () => {
  colorPicker.click();
});

// Al elegir color, se queda en draft (local)
colorPicker.addEventListener("input", () => {
  draftColor = colorPicker.value.toUpperCase();
  dirty = true;
  render();
});

// Prender: ahora sí guarda y después sincroniza (ya no se resetea)
btnSend.addEventListener("click", async () => {
  await sendState();
  dirty = false;     // ya se envió
  await pullState(); // sincroniza con server
});

// Apagar: reset solo de cantidad y guarda
btnOff.addEventListener("click", async () => {
  draftCount = 0;
  dirty = true;
  render();

  await sendState();
  dirty = false;
  await pullState();
});

/* ========= INIT ========= */
makeDots(dots, MAX);
makeDots(barDots, MAX);
pullState();

// Puedes dejarlo en 2000, pero ya NO te va a pisar cambios locales
setInterval(pullState, 2000);